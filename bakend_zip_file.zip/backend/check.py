import bcrypt as _bcrypt
version = getattr(_bcrypt, '__version__', '<unknown>')

print(version)